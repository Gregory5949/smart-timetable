create function get_data(person_id character varying) returns character varying
    language plpgsql
as
$$
declare
   event_id varchar;
begin
   select event_attendees.event_id
   into event_id
   from event_attendees
   LIMIT 4;
   return event_id;
end;
$$;

alter function get_data(varchar) owner to postgres;

