create function get_film_count(len_from integer, len_to integer) returns character varying
    language plpgsql
as
$$
declare
   film_count varchar;
begin
   select id
   into film_count
   from events;
   return film_count;
end;
$$;

alter function get_film_count(integer, integer) owner to postgres;

